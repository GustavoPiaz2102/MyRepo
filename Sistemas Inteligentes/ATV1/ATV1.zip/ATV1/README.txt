Como usar:

    - Em um computador com linux de preferencia de base ubuntu execute o arquivo main dentro da pasta dist
    - Ele está com tudo que é necessario para rodar
    - Caso o arquivo não esteja com a permissão adequada utilize "sudo chmod +x main" para seder permissão de execução ao arquivo

Jogo:

    - Defina o tamanho do labirinto que será gerado e veja a corrida acontecer
    - Ao fim , as posições que cada um percorreu serão mostradas de acordo com o requisistado pelo professor